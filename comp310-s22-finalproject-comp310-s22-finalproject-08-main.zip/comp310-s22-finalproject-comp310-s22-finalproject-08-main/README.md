# Final Project

**Please see the assignment instructions in Canvas as well as READMEs in the individual provided code packages (submodules).** 

*You must manually initially add the submodule for your Final Projct API design groups common repository.   This submodule will use a "submodule path" (mapping to a folder in the project) of <code>src/common</code>.  When the API is finalized, this submodule will be replaced with that for the class's final API.* 

Please see the Canvas pages, "Using the OwlMaps Library", "Using the Discovery Server Package", "Using the PubSubSync Library" and the "ChatApp and Final Project Resources", for documentation and usage directions.  See the individual submodule READMEs and Javadocs for additional information.   Use the "Client+Cerver" discovery server configuration mode for the application.

### IMPORTANT: Put all assignment code (except common API) under a package name with the team's NetIDs, e.g. netid1_netid2.

This will prevent name clashes when transmitting classes.   Also, don't forget to change the module name in the <code>module-info.java</code> file.

**Final Project API design group** Group C https://canvas.rice.edu/courses/47882/pages/final-project-design-group-c

## List ALL Partner Names and NetIDs:
1. jp95 Jinyu Pei
1. yh82 Alexia Huang

## Notes to Staff:
Our packages "GUI preview" and "map" are code snippets for testing and are not part of the actual final project code, so we did not do full javadoc on those two packages. We did UML and javadoc on other packages. 

Implemented custom message types that we send from server to the client for them to communicate between each other:
Our server is able to handle all api-related messages and commands. We have implemented all customized messages and commands.
We have also created our own message types for our game design purpose.

**messages for communication, team creation & joining, and game initialization:**
1. ICreateTeamMsg - msg for creating teams. 
2. IInfoPanelMsg - msg sending an info panel with basic game rules introduction
3. IGlobalUpdateTeamMsg - msg for updating available teams
4. IJoinTeamMsg - msg for joining teams. 
5. IJoinTeamMVCMsg - msg sending the game lobby panel
6. IJoinTeamSuccessMsg - msg indicating a success in a client's team joining
7. IReadyMsg - a client sends this msg to server to indicate that he is ready for the game
8. ISendGlonalMsg - msg for sending message to all players through the lobby gui panel
9. ITeamListMsg - msg holding available team list data
10. IClient2GUIAdapterJT - adapter for the game lobby gui

**messages for game related funcationalities**
1. IMapMsg - msg for sending a designed JPanel with a map in the middle
2. IAttackMsg - msg that a player wants to attack another player
3. IDeathMsg - msg that a player is dead
4. IDiscoveryMsgIF - msg that a player is discovered by another player
5. IFinalMsg - msg for holding the final ritual
6. IClient2GUIAdapter - adapter for the map gui
7. IMapTextGlobalMsg - msg for sending and displaying text on the map gui
8. ISetupMapMsg - msg for map set up
9. ISuccessMsg - msg that a team wins
10. IUpdateGUIListMsg - msg for updateing 
11. IUpdateTeamStatMsg - msg for updating statistics in the team
12. IUpdateMembersMsg - msg for updating team members
13. IUpdatePlaceMsg - msg for updating a player's location
14. IUpdateTeamMsg - msg for updating teams

Implementation for MS2 is in the branch called mile_stone_2.

## Application Notes:
(Edit this section to include instructions on how to run your submitted application as well as 
any other non-code information required by the assignment )

Launch the server controller and connect to the discovery system

Lauch the client controller and connect to the server through discovery system

Select the server from the droplist and click request, you will be automatically invited to the game lobby. This will produce a customized UI as well. (Ability to send a room-level message that creates a custom UI on the receiving application)

Create a team, or join an existing team

Send message locally or globally using two send message buttons (Ability to demonstrate inter-team communications)

for instructions on how to play the game,
See link: (please open with a rice account) https://docs.google.com/document/d/1WnMiOeVfBbVe3RxV_V9UQ-9YkjoBgC9gJQQEvm-pygo/edit?usp=sharing





