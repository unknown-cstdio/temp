package jp95_yh82.server.controller;

import java.util.function.Consumer;

import javax.swing.SwingUtilities;

import hw07.engine.model.EngineModel;
import hw07.engine.model.IModelViewAdapterEngine;
import hw07.engine.view.EngineView;
import hw07.engine.view.IViewModelAdapterEngine;
import provided.discovery.IEndPointData;
import provided.discovery.impl.model.DiscoveryModelPubOnly;
import provided.discovery.impl.view.DiscoveryPanel;
import provided.discovery.impl.view.IDiscoveryPanelAdapter;
import provided.logger.ILogger;
import provided.logger.ILoggerControl;
import provided.logger.LogLevel;
import provided.remoteCompute.compute.ICompute;

/**
 * The engine controller
 */
public class EngineController {

	/**
	 * the model
	 */
	private EngineModel engineModel;

	/**
	 * the view
	 */
	private EngineView engineView;

	/**
	 * the logger
	 */
	private ILogger systemLog = ILoggerControl.getSharedLogger();

	/**
	 * the dynamic control panel
	 */
	private DiscoveryPanel<IEndPointData> discPnl;
	/**
	 * the component on the discovery panel for connection
	 */
	private DiscoveryModelPubOnly<ICompute> disModel;

	/**
	 * The constructor
	 */
	public EngineController() {
		systemLog.setLogLevel(LogLevel.DEBUG);

		discPnl = new DiscoveryPanel<IEndPointData>(new IDiscoveryPanelAdapter<IEndPointData>() {

			@Override
			public void connectToDiscoveryServer(String category, boolean watchOnly,
					Consumer<Iterable<IEndPointData>> endPtsUpdateFn) {
				disModel.connectToDiscoveryServer(category, endPtsUpdateFn);

			}

			@Override
			public void connectToEndPoint(IEndPointData selectedValue) {
				disModel.connectToEndPoint(selectedValue);
			}

		}, false, true);

		disModel = new DiscoveryModelPubOnly<ICompute>(systemLog);

		engineModel = new EngineModel(systemLog, new IModelViewAdapterEngine() {
			@Override
			public void dispMsg(String msg) {
				engineView.append(msg);
			}
		});
		engineView = new EngineView(new IViewModelAdapterEngine() {
			@Override
			public void quit() {
				engineModel.stop();
			}

			@Override
			public void sendMsg(String msg) {
				engineModel.sendMsgToClient(msg);
			}
		});
	}

	/**
	 * Start the controller
	 */
	public void start() {
		engineModel.start();
		discPnl.start();
		disModel.start(engineModel.getRMIUtils(), "Team24", ICompute.BOUND_NAME);
		engineView.addCtrlComponent(discPnl);
		engineView.start();
	}

	/**
	 * The main function
	 * @param args input arguments
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				(new EngineController()).start();
			}
		});
	}

}
