package jp95_yh82.server.model;

/**
 * The Engine's model-view adapter
 */
public interface IModelViewAdapterEngine {

	/**
	 * for input message display
	 * @param msg the input message
	 */
	void dispMsg(String msg);
}
