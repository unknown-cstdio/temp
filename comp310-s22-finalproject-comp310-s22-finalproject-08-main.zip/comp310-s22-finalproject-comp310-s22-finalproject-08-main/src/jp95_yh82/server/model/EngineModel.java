package jp95_yh82.server.model;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import provided.logger.ILogEntry;
import provided.logger.ILogEntryFormatter;
import provided.logger.ILogEntryProcessor;
import provided.logger.ILogger;
import provided.logger.ILoggerControl;
import provided.logger.LogLevel;
import provided.remoteCompute.compute.ICompute;
import provided.remoteCompute.compute.ILocalTaskViewAdapter;
import provided.remoteCompute.compute.IRemoteTaskViewAdapter;
import provided.remoteCompute.compute.ITask;
import provided.remoteCompute.engine.model.IEngineModel;
import provided.rmiUtils.IRMIUtils;
import provided.rmiUtils.IRMI_Defs;
import provided.rmiUtils.RMIUtils;

/**
 * The engine model
 */
public class EngineModel implements IEngineModel {

	/**
	 * logger for client's view info output
	 */
	private ILogger viewLog;
	/**
	 * logger for system connection
	 */
	private ILogger systemLog;
	/**
	 * rmiutils for getting local ip address
	 */
	private IRMIUtils utils;
	/**
	 * the local task-view adapter
	 */
	private ILocalTaskViewAdapter engineAdapter = ILocalTaskViewAdapter.DEFAULT_ADAPTER;
	/**
	 * the model-view adapter
	 */
	private IModelViewAdapterEngine modelView;
	/**
	 * the remote task-view adapter for client
	 */
	private IRemoteTaskViewAdapter stubClient;
	/**
	 * the remote task-view adapter for engine
	 */
	private IRemoteTaskViewAdapter stubEngine;
	/**
	 * the registry
	 */
	private Registry reg;
	/**
	 * the proxy
	 */
	private ICompute stubServer;

	/**
	 * the ICompute server
	 */
	private ICompute server = new ICompute() {

		@Override
		public <T extends Serializable> T executeTask(ITask<T> t) throws RemoteException {
			modelView.dispMsg("Current Task Being Executed : " + t);
			t.setTaskViewAdapter(engineAdapter);
			T executeVal = t.execute();
			modelView.dispMsg("Task Result: " + t.getFormatter().format(executeVal));
			return t.execute();
		}

		@Override
		public IRemoteTaskViewAdapter setTextAdapter(IRemoteTaskViewAdapter clientTVAStub) throws RemoteException {
			stubClient = clientTVAStub;
			stubClient.append("Acquired Server");
			return stubEngine;
		}

	};

	/**
	 * The constructor
	 * @param logger the input logger
	 * @param adp the input adapter
	 */
	public EngineModel(ILogger logger, IModelViewAdapterEngine adp) {
		this.systemLog = logger;
		this.modelView = adp;
		utils = new RMIUtils(logger);
		viewLog = ILoggerControl.makeLogger(new ILogEntryProcessor() {
			ILogEntryFormatter formatter = ILogEntryFormatter.MakeFormatter("[%1s] %2s");

			@Override
			public void accept(ILogEntry logEntry) {
				EngineModel.this.modelView.dispMsg(formatter.apply(logEntry));

			}

		}, LogLevel.INFO);
		viewLog.append(systemLog);
		this.reg = this.utils.getLocalRegistry();
	}

	@Override
	public void start() {
		utils.startRMI(IRMI_Defs.CLASS_SERVER_PORT_CLIENT);
		IRemoteTaskViewAdapter currEngStub = new IRemoteTaskViewAdapter() {

			@Override
			public void append(String s) throws RemoteException {
				modelView.dispMsg(s);
			}
		};
		try {
			int port = IRemoteTaskViewAdapter.BOUND_PORT_SERVER;
			stubEngine = (IRemoteTaskViewAdapter) UnicastRemoteObject.exportObject(currEngStub, port);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			stubServer = (ICompute) UnicastRemoteObject.exportObject(server, ICompute.BOUND_PORT);
		} catch (Exception e) {
			e.printStackTrace();
		}

		reg = utils.getLocalRegistry();
		viewLog.log(LogLevel.INFO, "Connected to server");

		try {
			reg.rebind(ICompute.BOUND_NAME, stubServer);
			viewLog.log(LogLevel.INFO, "The Local Registry is : " + reg);
		} catch (Exception e) {
			e.printStackTrace();
			quit(-1);
		}
		// TODO Auto-generated method stub

	}

	/**
	 * Stop connection and exit the execution of the code
	 * @param exitCode input integer
	 */
	public void quit(int exitCode) {
		utils.stopRMI();
		System.exit(exitCode);
	}

	@Override
	public void stop() {
		try {
			reg.unbind(ICompute.BOUND_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}
		utils.stopRMI();

	}

	@Override
	public void sendMsgToClient(String text) {
		// TODO Auto-generated method stub
		try {
			stubClient.append(text);
		} catch (RemoteException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Get RMI utils
	 * @return the retrieved RMI object
	 */
	public IRMIUtils getRMIUtils() {
		return this.utils;
	}

}
