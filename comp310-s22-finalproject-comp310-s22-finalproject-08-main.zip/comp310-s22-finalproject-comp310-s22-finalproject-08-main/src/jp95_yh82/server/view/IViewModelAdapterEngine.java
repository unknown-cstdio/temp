package jp95_yh82.server.view;

/**
 * Engine's view-model adapter
 */
public interface IViewModelAdapterEngine {
	/**
	 * stop and quit the server
	 */
	void quit();

	/**
	 * for message sending
	 * @param msg the input message
	 */
	void sendMsg(String msg);

}
