package jp95_yh82.server.view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.BoxLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import javax.swing.JTextArea;

/**
 * GUI window for engine view
 * @author sunfl
 *
 */
public class EngineView extends JFrame {

	/**
	 * Serial UID
	 */
	private static final long serialVersionUID = -3091752698636359381L;
	/**
	 * 
	 */
	private JPanel contentPane;
	/**
	 * 
	 */
	private final JPanel panelNorth = new JPanel();

	/**
	 * panel that holds communication related functionalities
	 */
	private final JPanel connectPnl = new JPanel();
	/**
	 * button that disconnects from the server
	 */
	private final JButton quitBtn = new JButton("Quit");
	/**
	 * text field that takes message input
	 */
	private final JTextField sendMsgTxt = new JTextField();
	/**
	 * button that sends the input message
	 */
	private final JButton sendBtn = new JButton("Send");
	/**
	 * panel for layout
	 */
	private final JPanel panel_5 = new JPanel();
	/**
	 * text field for category input
	 */
	private final JTextField categoryTxt = new JTextField();
	/**
	 * the veiw-model engine adapter
	 */
	private IViewModelAdapterEngine adp;
	/**
	 * a dynamically controlled panel
	 */
	private final JScrollPane spDisplay = new JScrollPane();
	/**
	 * a text area for found register display
	 */
	private final JTextArea taDisplay = new JTextArea();

	/**
	 * The constructor
	 * @param adp the view-model engine adapter
	 */
	public EngineView(IViewModelAdapterEngine adp) {
		this.adp = adp;
		categoryTxt.setBorder(new TitledBorder(null, "Category", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		categoryTxt.setToolTipText("textfield for category input");
		categoryTxt.setColumns(10);
		sendMsgTxt.setToolTipText("Textfield for message input");
		sendMsgTxt.setBorder(new TitledBorder(null, "Send msg to remote client's view", TitledBorder.LEADING,
				TitledBorder.TOP, null, null));
		sendMsgTxt.setColumns(10);
		initGUI();
	}

	/**
	 * the GUI initialization
	 */
	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 754, 353);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		//		setContentPane(contentPane);

		getContentPane().add(contentPane, BorderLayout.NORTH);
		panelNorth.setToolTipText("General panel holding all operational funcionalities");
		contentPane.add(panelNorth, BorderLayout.NORTH);
		panelNorth.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		connectPnl.setToolTipText("panel that holds communication related functionalities");

		panelNorth.add(connectPnl);
		connectPnl.setLayout(new BoxLayout(connectPnl, BoxLayout.Y_AXIS));

		connectPnl.add(sendMsgTxt);
		panel_5.setToolTipText("panel for layout");

		connectPnl.add(panel_5);
		panel_5.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		quitBtn.setToolTipText("Close the engine view and stops the server on click");
		quitBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				adp.quit();
			}
		});
		panel_5.add(quitBtn);
		panel_5.add(sendBtn);
		sendBtn.setToolTipText("send the input message to connected client's view on click");
		sendBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				adp.sendMsg(sendMsgTxt.getText());
			}
		});

		getContentPane().add(spDisplay, BorderLayout.CENTER);
		taDisplay.setToolTipText("Text area display");
		taDisplay.setRows(20);

		spDisplay.setViewportView(taDisplay);
		//		discoveryPnl.setToolTipText("discovery server panel");
		//		discoveryPnl.setBorder(new TitledBorder(null, "Discovery Server", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		//		
		//		panel.add(discoveryPnl);
		//		
		//		discoveryPnl.add(panel_3);
		//		panel_3.setLayout(new GridLayout(0, 1, 0, 0));
		//		
		//		panel_3.add(categoryTxt);
		//		watchOnlyChkbx.setToolTipText("enable watch only view on click");
		//		
		//		panel_3.add(watchOnlyChkbx);
		//		connectBtn.setToolTipText("Connect to the corresponding server on click");
		//		
		//		panel_3.add(connectBtn);
		//		
		//		discoveryPnl.add(panel_4);
		//		panel_4.setLayout(new BoxLayout(panel_4, BoxLayout.Y_AXIS));
		//		registerPtsTxt.setBorder(new TitledBorder(null, "Registered Endpoints", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		//		registerPtsTxt.setWrapStyleWord(true);
		//		
		//		panel_4.add(registerPtsTxt);
		//		getEndPtLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
		//		
		//		panel_4.add(getEndPtLbl);

		//		getContentPane().add(MsgProcessTxt, BorderLayout.CENTER);
	}

	/**
	 * Launch the application.
	 */
	//	public static void main(String[] args) {
	//		EventQueue.invokeLater(new Runnable() {
	//			public void run() {
	//				try {
	//					EngineView frame = new EngineView();
	//					frame.setVisible(true);
	//				} catch (Exception e) {
	//					e.printStackTrace();
	//				}
	//			}
	//		});
	//	}

	/**
	
	* Set the frame visible and start the frame
	 */
	public void start() {
		this.setVisible(true);
	}

	/**
	 * add dynamic control component
	 * @param comp the input component
	 */
	public void addCtrlComponent(JComponent comp) {
		contentPane.add(comp);
		validate();
		pack();
	}

	/**
	 * Append message to display text area
	 * @param msg String message
	 */
	public void append(String msg) {
		taDisplay.append(msg + "\n");
	}

}
