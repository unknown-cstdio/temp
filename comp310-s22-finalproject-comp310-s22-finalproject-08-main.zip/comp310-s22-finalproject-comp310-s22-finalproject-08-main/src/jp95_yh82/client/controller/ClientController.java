package jp95_yh82.client.controller;

import java.io.Serializable;
import java.util.function.Consumer;

import javax.swing.SwingUtilities;


import provided.discovery.IEndPointData;
import provided.discovery.impl.model.DiscoveryModelWatchOnly;
import provided.discovery.impl.model.IDiscoveryModelToViewAdapter;
import provided.discovery.impl.view.DiscoveryPanel;
import provided.discovery.impl.view.IDiscoveryPanelAdapter;
import provided.logger.ILogger;
import provided.logger.ILoggerControl;
import provided.logger.LogLevel;


/**
 * Controller on the client's side
 *
 */
public class ClientController {

	/**
	 * the logger
	 */
	private ILogger systemLog = ILoggerControl.getSharedLogger();

	/**
	 * the client model
	 */
	private ClientModel clientModel;

	/**
	 * the client view
	 */
	@SuppressWarnings("rawtypes")
	private ClientView<ITaskFactory> clientView;

	/**
	 * the dynamic control panel for end point discovery
	 */
	private DiscoveryPanel<IEndPointData> discPnl;

	/**
	 * the dynamic control panel for watch only functionalities
	 */
	private DiscoveryModelWatchOnly<ICompute> disModel;

	/**
	 * the constructor
	 */
	@SuppressWarnings("rawtypes")
	public ClientController() {
		systemLog.setLogLevel(LogLevel.DEBUG);

		discPnl = new DiscoveryPanel<IEndPointData>(new IDiscoveryPanelAdapter<IEndPointData>() {

			@Override
			public void connectToDiscoveryServer(String category, boolean watchOnly,
					Consumer<Iterable<IEndPointData>> endPtsUpdateFn) {
				disModel.connectToDiscoveryServer(category, endPtsUpdateFn);

			}

			@Override
			public void connectToEndPoint(IEndPointData selectedValue) {
				disModel.connectToEndPoint(selectedValue);

			}

		}, false, true);
		disModel = new DiscoveryModelWatchOnly<ICompute>(systemLog, new IDiscoveryModelToViewAdapter<ICompute>() {

			@Override
			public void addStub(ICompute stub) {
				clientModel.connectToStub(stub);

			}

		});

		clientModel = new ClientModel(systemLog, new IModelViewAdapterClient() {

			@Override
			public void dispMsg(String msg) {
				clientView.append(msg);
			}
		});

		clientView = new ClientView<ITaskFactory>(new IViewModelAdapterClient<ITaskFactory>() {

			@Override
			public void quit() {
				clientModel.stop();
			}

			@Override
			public ITaskFactory addTask(String classpath) {
				return clientModel.makeTaskFac(classpath);
			}

			@Override
			public ITaskFactory combineFac(ITaskFactory task1, ITaskFactory task2) {
				return clientModel.combineFac(task1, task2);
			}

			@Override
			public void sendMsg(String s) {
				clientModel.sendMsgToComputeEngine(s);

			}

			@Override
			public String connectTo(String currIPAddress) {
				return clientModel.connectTo(currIPAddress);
			}

			@SuppressWarnings({ "unchecked" })
			@Override
			public <T extends Serializable> String runTaskFromFac(ITaskFactory taskFac, String vals) {
				return clientModel.runTask(taskFac.make(vals));
			}

		});
	}

	/**
	 * start the controller
	 */
	public void start() {
		clientModel.start();
		discPnl.start();
		disModel.start(clientModel.getRMIUtils());
		clientView.addCtrlComponent(discPnl);
		clientView.start();
	}

	/**
	 * The main function
	 * @param args input arguments
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				(new ClientController()).start();
			}
		});
	}

}
