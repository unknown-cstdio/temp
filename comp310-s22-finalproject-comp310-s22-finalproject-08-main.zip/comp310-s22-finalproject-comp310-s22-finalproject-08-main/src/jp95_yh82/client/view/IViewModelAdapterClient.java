package jp95_yh82.client.view;

import java.io.Serializable;

/**
 * client's view-model adapter
 * @param <TTaskListItem> a drop list item
 */
public interface IViewModelAdapterClient<TTaskListItem> {

	/**
	 * stop the connection
	 */
	void quit();

	/**
	 * for task loading
	 * @param classpath the input task path
	 * @return a loaded task object(task factory)
	 */
	TTaskListItem addTask(String classpath);

	/**
	 * combine two input tasks into one
	 * @param task1 input task 1
	 * @param task2 input task 2
	 * @return the combination object of the two input tasks
	 */
	TTaskListItem combineFac(TTaskListItem task1, TTaskListItem task2);

	/**
	 * Send the input message
	 * @param s the input message
	 */
	void sendMsg(String s);

	/**
	 * Connect client to selected server address
	 * @param currIPAddress the input ip address
	 * @return a message showing the connection status
	 */
	String connectTo(String currIPAddress);

	/**
	 * load tasks for running
	* @param <T> the type of data the task object contain
	* @param taskFac the input task factory
	* @param vals the input parameter
	* @return the result of the execution of the task
	*/
	<T extends Serializable> String runTaskFromFac(TTaskListItem taskFac, String vals);
}
