package jp95_yh82.client.view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.BoxLayout;
import java.awt.Component;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextArea;

/**
 * The client GUI
 * @param <TTaskListItem> component in the GUI
 */
public class ClientView<TTaskListItem> extends JFrame {

	/**
	 * for serialization
	 */
	private static final long serialVersionUID = 713097952795429530L;
	/**
	 * the general panel containing all functionalities
	 */
	private JPanel contentPane;
	/**
	 * the north panel
	 */
	private final JPanel panelNorth = new JPanel();
	/**
	 * the panel holding connection related functionalities
	 */
	private final JPanel connectPnl = new JPanel();
	/**
	 * the panel holding task-related functionalities
	 */
	private final JPanel panel_2 = new JPanel();
	/**
	 * the panel holding task-related functionalities
	 */
	private final JPanel runTaskPnl = new JPanel();

	/**
	 * the panel holding connection related functionalities
	 */
	private final JPanel remoteHostPnl = new JPanel();
	/**
	 * the text box for ip input and connection by hand
	 */
	private final JTextField ipTxt = new JTextField();
	/**
	 * the button connecting client to the host at the inputted ip address
	 */
	private final JButton connectHostBtn = new JButton("Connect");
	/**
	 * the text field for message input
	 */
	private final JTextField messageTxt = new JTextField();
	/**
	 * the button for message sending
	 */
	private final JButton sendBtn = new JButton("Send");
	/**
	 * the button for exiting the connection
	 */
	private final JButton quitBtn = new JButton("Quit");
	/**
	 * the panel holding task related functionalities
	 */
	private final JPanel taskPnl = new JPanel();
	/**
	 * the text field for text name input
	 */
	private final JTextField taskTxt = new JTextField();
	/**
	 * the button that adds input task to the drop list
	 */
	private final JButton add2LstBtn = new JButton("Add to lists");
	/**
	 * the drop list holding task objects
	 */
	private final JComboBox<TTaskListItem> taskDdl1 = new JComboBox<>();
	/**
	 * the drop list holding task objects
	 */
	private final JComboBox<TTaskListItem> taskDdl2 = new JComboBox<>();
	/**
	 * the button combining two tasks into one
	 */
	private final JButton combineTskBtn = new JButton("Combine Tasks");
	/**
	 * the text field for parameter input
	 */
	private final JTextField paramTxt = new JTextField();
	/**
	 * the button that tell stub to runs the required task remotely and get the result
	 */
	private final JButton runTxt = new JButton("Run Task");

	/**
	 * text field for category input
	 */
	private final JTextField categoryTxt = new JTextField();
	/**
	 * text area for processing status output
	 */
	private final JTextArea ProcessingTxt = new JTextArea();
	/**
	 * a dynamically controlled panel
	 */
	private final JScrollPane spDisplay = new JScrollPane();
	/**
	 * a text area for found register display
	 */
	private final JTextArea taDisplay = new JTextArea();

	/**
	 * client's view-model adapter
	 */
	private IViewModelAdapterClient<TTaskListItem> adp;

	/**
	 * Launch the application.
	 */
	//	public static void main(String[] args) {
	//		EventQueue.invokeLater(new Runnable() {
	//			public void run() {
	//				try {
	//					ClientView frame = new ClientView();
	//					frame.setVisible(true);
	//				} catch (Exception e) {
	//					e.printStackTrace();
	//				}
	//			}
	//		});
	//	}

	/**
	 * Create the frame.
	 * @param adp the view-model adapter
	 */
	public ClientView(IViewModelAdapterClient<TTaskListItem> adp) {
		categoryTxt.setBorder(new TitledBorder(null, "Category", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		categoryTxt.setColumns(10);
		paramTxt.setToolTipText("text for parameter input");
		paramTxt.setBorder(
				new TitledBorder(null, "Run Parameter:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		paramTxt.setColumns(10);
		taskTxt.setToolTipText("textbox for task name input");
		taskTxt.setBorder(new TitledBorder(null, "New Task", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		taskTxt.setColumns(10);
		messageTxt.setToolTipText("Textfield for message input");
		messageTxt.setColumns(10);
		ipTxt.setToolTipText("Textfield for ip input");
		ipTxt.setColumns(10);
		this.adp = adp;
		initGUI();
	}

	/**
	 * GUI initialization
	 */
	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 919, 367);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		getContentPane().add(contentPane, BorderLayout.NORTH);
		panelNorth.setToolTipText("General panel holding all operational funcionalities");

		contentPane.add(panelNorth, BorderLayout.NORTH);
		panelNorth.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		connectPnl.setToolTipText("The panel holding connection-related functionalities");

		panelNorth.add(connectPnl);
		connectPnl.setLayout(new BoxLayout(connectPnl, BoxLayout.Y_AXIS));
		remoteHostPnl.setToolTipText("Panel holding host-connection-related functionalities");
		remoteHostPnl
				.setBorder(new TitledBorder(null, "Remote Host", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		connectPnl.add(remoteHostPnl);
		remoteHostPnl.setLayout(new BoxLayout(remoteHostPnl, BoxLayout.Y_AXIS));

		remoteHostPnl.add(ipTxt);
		connectHostBtn.setToolTipText("connect to corresponding host on click");
		connectHostBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		connectHostBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String currIPAddress = ipTxt.getText();
				ProcessingTxt.append("Attempting to connect to" + currIPAddress + "...\n");
				ProcessingTxt.append("Connection Status: " + adp.connectTo(currIPAddress) + "\n");
			}

		});

		remoteHostPnl.add(connectHostBtn);

		remoteHostPnl.add(messageTxt);
		sendBtn.setToolTipText("Send to corresponding host on click");
		sendBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		sendBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				adp.sendMsg(messageTxt.getText());
			}

		});
		remoteHostPnl.add(sendBtn);

		quitBtn.setToolTipText("Close the client view and quit the connection on click");
		quitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		quitBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				adp.quit();
				System.exit(0);
			}

		});

		connectPnl.add(quitBtn);

		panelNorth.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		taskPnl.setToolTipText("Panel holding task-related functionalities");

		panel_2.add(taskPnl);
		taskPnl.setLayout(new BoxLayout(taskPnl, BoxLayout.Y_AXIS));

		taskPnl.add(taskTxt);
		add2LstBtn.setToolTipText("load and add an inputed task to the task drop list on click");
		add2LstBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		add2LstBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TTaskListItem currTask = adp.addTask(taskTxt.getText());
				if (currTask != null) {
					taskDdl1.insertItemAt(currTask, 0);
					taskDdl2.insertItemAt(currTask, 0);
					taskDdl1.setSelectedIndex(0);
					taskDdl2.setSelectedIndex(0);
				}
			}

		});

		taskPnl.add(add2LstBtn);
		taskDdl1.setToolTipText("droplist holding loaded task objects");

		taskPnl.add(taskDdl1);
		taskDdl2.setToolTipText("droplist holding loaded task objects");

		taskPnl.add(taskDdl2);
		combineTskBtn.setToolTipText("Combine the two tasks on the droplist on click");
		combineTskBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		combineTskBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TTaskListItem t1 = taskDdl1.getItemAt(taskDdl1.getSelectedIndex());
				TTaskListItem t2 = taskDdl2.getItemAt(taskDdl2.getSelectedIndex());
				TTaskListItem comp = adp.combineFac(t1, t2);

				taskDdl1.insertItemAt(comp, 0);
				taskDdl2.insertItemAt(comp, 0);
			}

		});
		taskPnl.add(combineTskBtn);

		runTaskPnl.setToolTipText("Panel that runs a task with given parameter input");

		panelNorth.add(runTaskPnl);
		runTaskPnl.setLayout(new BoxLayout(runTaskPnl, BoxLayout.Y_AXIS));

		runTaskPnl.add(paramTxt);
		runTxt.setToolTipText("Call the stub to run the selected task on click");
		runTxt.setAlignmentX(Component.CENTER_ALIGNMENT);
		runTxt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(paramTxt.getText());
				append(adp.runTaskFromFac(taskDdl1.getItemAt(taskDdl1.getSelectedIndex()), paramTxt.getText()));
			}
		});

		spDisplay.setToolTipText("Display scroll panel");

		getContentPane().add(spDisplay, BorderLayout.CENTER);
		taDisplay.setToolTipText("Text area display");
		taDisplay.setRows(20);

		spDisplay.setViewportView(taDisplay);

		runTaskPnl.add(runTxt);
	}

	/**
	 * for message merging
	 * @param msg input message
	 */
	public void append(String msg) {
		taDisplay.append(msg + "\n");

	}

	/**
	 * for dynamic control panel addition
	 * @param comp input component to be placed on the control panel
	 */
	public void addCtrlComponent(JComponent comp) {
		contentPane.add(comp);
		validate();
		pack();
	}

	/**
	 * start the gui
	 */
	public void start() {
		setVisible(true);
	}

}
