package jp95_yh82.client.model;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import hw07.tm45yh82.tasks.CompTask;
import provided.logger.ILogEntry;
import provided.logger.ILogEntryFormatter;
import provided.logger.ILogEntryProcessor;
import provided.logger.ILogger;
import provided.logger.ILoggerControl;
import provided.logger.LogLevel;
import provided.remoteCompute.client.model.IClientModel;
import provided.remoteCompute.client.model.taskUtils.ITaskFactory;
import provided.remoteCompute.client.model.taskUtils.ITaskFactoryLoader;
import provided.remoteCompute.client.model.taskUtils.SingletonTaskFactoryLoader;
import provided.remoteCompute.compute.ICompute;
import provided.remoteCompute.compute.IRemoteTaskViewAdapter;
import provided.remoteCompute.compute.ITask;
import provided.rmiUtils.IRMIUtils;
import provided.rmiUtils.IRMI_Defs;
import provided.rmiUtils.RMIUtils;

/**
 * The Client Model
 */
public class ClientModel implements IClientModel {
	/**
	 * logger for client's view info output
	 */
	private ILogger viewLog;
	/**
	 * logger for system connection
	 */
	private ILogger systemLog;

	/**
	 * rmiUtils for ip detection
	 */
	private IRMIUtils rmiUtils;

	/**
	 * client's model-view adapter
	 */
	private IModelViewAdapterClient adp;

	/**
	 * the proxy
	 */
	private ICompute stubServer;

	/**
	 * task loader
	 */
	private ITaskFactoryLoader taskFactoryLoader = SingletonTaskFactoryLoader.SINGLETON;

	/**
	 * the view stub server adapter
	 */
	private IRemoteTaskViewAdapter viewStubServer = new IRemoteTaskViewAdapter() {

		@Override
		public void append(String s) throws RemoteException {
			adp.dispMsg(s);

		}

	};

	/**
	 * the view stub client adapter
	 */
	private IRemoteTaskViewAdapter viewStubClient = IRemoteTaskViewAdapter.NULL_ADAPTER;

	/**
	 * the Constructor
	 * @param logger logger for info output
	 * @param adp client's model-view adapter
	 */
	public ClientModel(ILogger logger, IModelViewAdapterClient adp) {
		this.systemLog = logger;
		this.adp = adp;
		rmiUtils = new RMIUtils(logger);

		viewLog = ILoggerControl.makeLogger(new ILogEntryProcessor() {
			ILogEntryFormatter formatter = ILogEntryFormatter.MakeFormatter("[%1s] %2s");

			@Override
			public void accept(ILogEntry logEntry) {
				ClientModel.this.adp.dispMsg(formatter.apply(logEntry));

			}

		}, LogLevel.INFO);
		viewLog.append(systemLog);
	}

	/**
	 * Get the internal IRMIUtils instance being used.    The discovery model start method needs the main model's IRMIUtils.
	 * ONLY call the method AFTER the model, i.e. the internal IRMIUtils, has been started!
	 * @return The internal IRMIUtils instance
	 */
	public IRMIUtils getRMIUtils() {
		return this.rmiUtils;
	}

	@Override
	public void start() {
		rmiUtils.startRMI(IRMI_Defs.CLASS_SERVER_PORT_CLIENT);
		try {
			viewStubClient = (IRemoteTaskViewAdapter) UnicastRemoteObject.exportObject(viewStubServer,
					IRemoteTaskViewAdapter.BOUND_PORT_CLIENT);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void stop() {
		rmiUtils.stopRMI();
	}

	@Override
	public String connectTo(String remoteRegistryIPAddr) {
		try {
			systemLog.log(LogLevel.INFO, "Locating registry at " + remoteRegistryIPAddr + "...");
			Registry registry = rmiUtils.getRemoteRegistry(remoteRegistryIPAddr);
			systemLog.log(LogLevel.INFO, "Found registry: " + registry);
			ICompute remoteStub = (ICompute) registry.lookup(ICompute.BOUND_NAME); // Replace "IRemoteStubType" and "BOUND_NAME" with the appropriate values for the application  
			systemLog.log(LogLevel.INFO, "Found remote stub: " + remoteStub);

			this.connectToStub(remoteStub);

		} catch (Exception e) {
			systemLog.log(LogLevel.ERROR, "Exception connecting to " + remoteRegistryIPAddr + ": " + e);
			e.printStackTrace();

			return "No connection established!";
		}
		return "Connection to " + remoteRegistryIPAddr + " established!";
	}

	@Override
	public void sendMsgToComputeEngine(String text) {
		try {
			systemLog.log(LogLevel.INFO, "");
			this.viewStubServer.append(text);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Connect client to the input stub
	 * @param computeStub the input stub
	 */
	public void connectToStub(ICompute computeStub) {
		this.stubServer = computeStub;
		try {
			this.viewStubServer = this.stubServer.setTextAdapter(viewStubClient);
			viewLog.log(LogLevel.INFO, "Text Adapter is : " + this.viewStubServer);
			this.viewStubServer.append("Client Group 24 connected!");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	@Override
	public <T extends Serializable> String runTask(ITask<T> task) {
		try {
			viewLog.log(LogLevel.INFO, "Current Task Being Executed : " + task);
			return task.getFormatter().format(stubServer.executeTask(task));
		} catch (RemoteException e) {
			viewLog.log(LogLevel.ERROR, "Exception in the remote method: " + e);
			e.printStackTrace();
		}
		return "Task Execution Error";
	}

	/**
	 * Method for combining two tasks
	 * @param <T> a serializable type
	 * @param t1 task 1
	 * @param t2 task 2
	 * @return a combined task
	 */
	@SuppressWarnings("rawtypes")
	public <T extends Serializable> ITaskFactory<T> combineFac(ITaskFactory t1, ITaskFactory t2) {
		if (t1 == null || t2 == null) {
			return null;
		}
		return new ITaskFactory<T>() {
			@SuppressWarnings("unchecked")
			public ITask<T> make(String param) {
				return new CompTask(t1.make(param), t2.make(param));
			}

			public String toString() {
				return t1.toString() + "-" + t2.toString();
			}
		};
	}

	/**
	 * for loading task factory with the given name
	 * @param classname input task name
	 * @return a loaded task factory object
	 */
	@SuppressWarnings("rawtypes")
	public ITaskFactory makeTaskFac(final String classname) {
		return taskFactoryLoader.load("hw07.tm45yh82.tasks." + classname);
	}

}
