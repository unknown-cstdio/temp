package jp95_yh82.client.model;

/**
 * Client's model-view adapter
 */
public interface IModelViewAdapterClient {

	/**
	 * for message display
	 * @param msg in input string message
	 */
	void dispMsg(String msg);
}
